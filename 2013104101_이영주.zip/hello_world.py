print("Hello, World.")
